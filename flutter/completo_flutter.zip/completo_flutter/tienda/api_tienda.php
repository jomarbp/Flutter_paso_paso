<?php
// Configuración de CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization, X-Requested-With');
header('Access-Control-Expose-Headers: Content-Length, X-JSON');
header('Access-Control-Max-Age: 86400');

// Manejar solicitudes OPTIONS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
   header('HTTP/1.1 200 OK');
   exit();
}

$conn = new mysqli("localhost", "root", "", "tienda_app");
if ($conn->connect_error) {
   die('Conexión Fallida: ' . $conn->connect_error);
}

$resource = isset($_GET['resource']) ? $_GET['resource'] : '';

// Determinar el método real
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST' && isset($_GET['_method'])) {
   $method = strtoupper($_GET['_method']);
}

error_log("Método detectado: " . $method);
error_log("Resource: " . $resource);

switch ($resource) {
   case 'categorias':
       handleCategorias($method, $conn);
       break;
   case 'productos':
       handleProductos($method, $conn);
       break;
   default:
       echo json_encode(["error" => "Recurso no encontrado"]);
       break;
}

function handleCategorias($method, $conn) {
   switch ($method) {
       case 'GET':
           $sql = "SELECT * FROM categorias";
           $result = $conn->query($sql);
           $categorias = [];
           while($row = $result->fetch_assoc()) {
               $categorias[] = $row;
           }
           echo json_encode($categorias);
           break;

       case 'POST':
           $data = json_decode(file_get_contents("php://input"), true);
           $stmt = $conn->prepare("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)");
           $stmt->bind_param("ss", $data['nombre'], $data['descripcion']);
           
           if($stmt->execute()) {
               echo json_encode(["message" => "Categoría creada con éxito"]);
           } else {
               echo json_encode(["error" => $stmt->error]);
           }
           break;

       case 'PUT':
           $data = json_decode(file_get_contents("php://input"), true);
           $stmt = $conn->prepare("UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?");
           $stmt->bind_param("ssi", $data['nombre'], $data['descripcion'], $data['id']);
           
           if($stmt->execute()) {
               echo json_encode(["message" => "Categoría actualizada con éxito"]);
           } else {
               echo json_encode(["error" => $stmt->error]);
           }
           break;

       case 'DELETE':
           $id = $_GET['id'];
           $stmt = $conn->prepare("DELETE FROM categorias WHERE id = ?");
           $stmt->bind_param("i", $id);
           
           if($stmt->execute()) {
               echo json_encode(["message" => "Categoría eliminada con éxito"]);
           } else {
               echo json_encode(["error" => $stmt->error]);
           }
           break;
   }
}

function handleProductos($method, $conn) {
   error_log("Método en handleProductos: " . $method);
   
   switch ($method) {
       case 'GET':
           $sql = "SELECT p.*, c.nombre as categoria_nombre 
                  FROM productos p 
                  LEFT JOIN categorias c ON p.categoria_id = c.id";
           $result = $conn->query($sql);
           $productos = [];
           while($row = $result->fetch_assoc()) {
               $productos[] = $row;
           }
           echo json_encode($productos);
           break;

       case 'POST':
           if (isset($_GET['_method']) && $_GET['_method'] === 'PUT') {
               handleProductoUpdate($conn);
           } else {
               handleProductoCreate($conn);
           }
           break;

       case 'PUT':
           handleProductoUpdate($conn);
           break;

       case 'DELETE':
           $id = $_GET['id'];
           
           // Primero obtener la información de la imagen
           $stmt = $conn->prepare("SELECT imagen_url FROM productos WHERE id = ?");
           $stmt->bind_param("i", $id);
           $stmt->execute();
           $result = $stmt->get_result();
           $producto = $result->fetch_assoc();

           // Luego eliminar el producto
           $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
           $stmt->bind_param("i", $id);
           
           if($stmt->execute()) {
               // Si hay una imagen, eliminarla del servidor
               if ($producto && $producto['imagen_url']) {
                   // Obtener la ruta local de la imagen desde la URL
                   $imagen_path = str_replace('/tienda/', '', $producto['imagen_url']);
                   $ruta_completa = __DIR__ . '/' . $imagen_path;
                   
                   // Intentar eliminar el archivo
                   if (file_exists($ruta_completa)) {
                       unlink($ruta_completa);
                   }
               }
               
               echo json_encode(["message" => "Producto eliminado con éxito"]);
           } else {
               http_response_code(500);
               echo json_encode(["error" => $stmt->error]);
           }
           break;
   }
}

function handleProductoCreate($conn) {
   $data = $_POST;
   $imagen_url = null;
   
   if (isset($_FILES['imagen'])) {
       $imagen = $_FILES['imagen'];
       $imagen_nombre = time() . '_' . basename($imagen['name']);
       $ruta_destino = 'imagenes/' . $imagen_nombre;
       
       if (!file_exists('imagenes')) {
           mkdir('imagenes', 0777, true);
       }
       
       if (move_uploaded_file($imagen['tmp_name'], $ruta_destino)) {
           $imagen_url = '/tienda/' . $ruta_destino;
       } else {
           http_response_code(500);
           echo json_encode(["error" => "Error al subir la imagen"]);
           return;
       }
   }

   $stmt = $conn->prepare("INSERT INTO productos (nombre, descripcion, precio, stock, categoria_id, imagen_url) VALUES (?, ?, ?, ?, ?, ?)");
   $stmt->bind_param("ssdiis", 
       $data['nombre'], 
       $data['descripcion'], 
       $data['precio'], 
       $data['stock'], 
       $data['categoria_id'], 
       $imagen_url
   );
   
   if($stmt->execute()) {
       echo json_encode(["message" => "Producto creado con éxito"]);
   } else {
       http_response_code(500);
       echo json_encode(["error" => $stmt->error]);
   }
}

function handleProductoUpdate($conn) {
   $data = $_POST;
   $id = $data['id'];
   
   error_log("Actualizando producto con ID: " . $id);
   
   // Obtener producto actual
   $stmt = $conn->prepare("SELECT imagen_url FROM productos WHERE id = ?");
   $stmt->bind_param("i", $id);
   $stmt->execute();
   $result = $stmt->get_result();
   $producto_actual = $result->fetch_assoc();
   
   // Mantener la imagen actual por defecto
   $imagen_url = $producto_actual['imagen_url'];
   
   // Procesar nueva imagen si existe
   if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
       $imagen = $_FILES['imagen'];
       $imagen_nombre = time() . '_' . basename($imagen['name']);
       $ruta_destino = 'imagenes/' . $imagen_nombre;
       
       if (!file_exists('imagenes')) {
           mkdir('imagenes', 0777, true);
       }
       
       if (move_uploaded_file($imagen['tmp_name'], $ruta_destino)) {
           $imagen_url = '/tienda/' . $ruta_destino;
           
           // Eliminar imagen anterior
           if ($producto_actual['imagen_url']) {
               $imagen_anterior = str_replace('/tienda/', '', $producto_actual['imagen_url']);
               if (file_exists($imagen_anterior)) {
                   unlink($imagen_anterior);
               }
           }
       }
   }
   
   $stmt = $conn->prepare("
       UPDATE productos 
       SET nombre = ?,
           descripcion = ?,
           precio = ?,
           stock = ?,
           categoria_id = ?,
           imagen_url = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?
   ");
   
   $stmt->bind_param("ssdiisi",
       $data['nombre'],
       $data['descripcion'],
       $data['precio'],
       $data['stock'],
       $data['categoria_id'],
       $imagen_url,
       $id
   );
   
   if ($stmt->execute()) {
       echo json_encode([
           "success" => true,
           "message" => "Producto actualizado con éxito"
       ]);
   } else {
       http_response_code(500);
       echo json_encode([
           "success" => false,
           "error" => "Error al actualizar el producto: " . $stmt->error
       ]);
   }
}

$conn->close();
?>